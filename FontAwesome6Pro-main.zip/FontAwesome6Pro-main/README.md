# FontAwesome6Pro


**ITS use personal but people can use it too**<br>
CLONING THIS REPOSITORY IF YOU GET LOCAL OR OFFLINE
<br>
You can use with this method<br>

This for use with cdn:
<br>
```
<link rel="stylesheet" href="https://atugatran.github.io/FontAwesome6Pro/css/all.min.css" >
 ```
<br>

Should get all.css for use fontawesome<br>
**Remember Put on the HEAD tag**<br>

**Enjoy 16.000 Font**
Alert don't use it
